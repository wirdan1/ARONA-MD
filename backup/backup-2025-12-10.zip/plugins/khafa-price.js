/*
   PRICELIST KHAFA TOPUP — VERSI TERBARU
   Sesuai respons API baru (array + field code, name, category, dll)
   Rapi, cantik, cepet, sultan approved!
*/

import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    let apikey = global.khafaApiKey
    if (!apikey || apikey.includes("your_api_key_here") || apikey === "kft_") {
        return m.reply(`Warning API Key KhafaTopUp belum diatur!\n\nIsi di settings.js:\n\nglobal.khafaApiKey = "apikey_lo_disini"`)
    }

    m.reply("Sedang mengambil pricelist terbaru dari KhafaTopUp...")

    try {
        const res = await fetch('https://khafatopup.my.id/h2h/layanan/price-list', {
            method: 'GET',
            headers: {
                'X-APIKEY': apikey,
                'Content-Type': 'application/json'
            }
        })

        if (!res.ok) throw `Error ${res.status}: Gagal konek ke server`
        const json = await res.json()

        if (!json.success || !Array.isArray(json.data)) throw "Data pricelist kosong atau format salah"

        let categories = {}

        json.data.forEach(item => {
            const cat = item.category || "Lainnya"
            if (!categories[cat]) categories[cat] = []
            categories[cat].push(item)
        })

        let teks = `*PRICELIST KHAFA TOPUP TERBARU*\n\n`
        teks += `_Update: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}_\n\n`

        const urutan = ["Pulsa Reguler", "Data Internet", "Paket Data", "E-Money", "Voucher Game", "PLN", "BPJS", "Lainnya"]

        for (let cat of urutan) {
            if (categories[cat]) {
                teks += `*[ ${cat.toUpperCase()} ]*\n`
                categories[cat].forEach(p => {
                    const status = p.status === "available" ? "Aktif" : "Tidak Aktif"
                    const harga = Number(p.price).toLocaleString('id-ID')
                    teks += `${status} ${p.provider} - ${p.name}\n`
                    teks += `   ├ Harga: *Rp ${harga}*\n`
                    teks += `   └ Kode: \`${p.code}\`\n\n`
                })
                teks += `\n`
            }
        }

        // Kategori lain yang gak masuk urutan
        for (let cat in categories) {
            if (!urutan.includes(cat)) {
                teks += `*[ ${cat.toUpperCase()} ]*\n`
                categories[cat].forEach(p => {
                    const status = p.status === "available" ? "Aktif" : "Tidak Aktif"
                    const harga = Number(p.price).toLocaleString('id-ID')
                    teks += `${status} ${p.provider || ''} ${p.name}\n`
                    teks += `   ├ Harga: *Rp ${harga}*\n`
                    teks += `   └ Kode: \`${p.code}\`\n\n`
                })
                teks += `\n`
            }
        }

        await conn.sendMessage(m.chat, {
            text: teks.trim(),
            contextInfo: {
                externalAdReply: {
                    title: "KHAFA TOPUP - HARGA TERMURAH",
                    body: "Pulsa, Data, Game, PLN, E-Money — Semua Ada!",
                    thumbnailUrl: "https://qu.ax/bJwgg.jpg",
                    sourceUrl: "https://khafatopup.my.id",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.log(e)
        m.reply(`Gagal ambil pricelist!\n\n${e}\n\nCoba lagi nanti ya bro, server lagi penuh atau maintenance.`)
    }
}

handler.help = ['price']
handler.tags = ['khafa']
handler.command = /^(price)$/i

export default handler