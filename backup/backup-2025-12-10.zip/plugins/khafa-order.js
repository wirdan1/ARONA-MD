// === ORDER QRIS + CANVAS CANTIK + NOTIF PESANAN BERHASIL OTOMATIS ===
import fetch from 'node-fetch'
import qs from 'qs'
import QRCode from 'qrcode'
import { createCanvas, loadImage } from 'canvas'
import moment from 'moment-timezone'
import fs from 'fs'

// Database pending (biar aman)
const pendingPath = './database/pendingQris.json'
if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true })
if (!fs.existsSync(pendingPath)) fs.writeFileSync(pendingPath, JSON.stringify({}))
let pendingData = JSON.parse(fs.readFileSync(pendingPath))

function savePending() {
  fs.writeFileSync(pendingPath, JSON.stringify(pendingData, null, 2))
}

// Generate QRIS Cantik (720x1080)
async function generateCustomQR(qrString) {
  const canvas = createCanvas(720, 1080)
  const ctx = canvas.getContext('2d')

  const bg = await loadImage('./media/qrisscustom.jpg') // ganti sama background kamu
  ctx.drawImage(bg, 0, 0, 720, 1080)

  const qrCanvas = createCanvas(500, 500)
  await QRCode.toCanvas(qrCanvas, qrString, {
    errorCorrectionLevel: 'H',
    margin: 2,
    width: 500,
    color: { dark: '#000000', light: '#0000' }
  })

  const x = (720 - 500) / 2
  const y = 595
  ctx.shadowColor = 'rgba(0,0,0,0.6)'
  ctx.shadowBlur = 20
  ctx.shadowOffsetY = 10
  ctx.drawImage(qrCanvas, x, y, 500, 500)
  ctx.shadowBlur = 0

  return canvas.toBuffer('image/png')
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    return m.reply(`*ORDER VIA QRIS (CUSTOM DESIGN)*

Contoh:
${usedPrefix + command} TSEL10GB | 085156789012
${usedPrefix + command} ML500 | 12345678(4321)
${usedPrefix + command} PLN50 | 531234567890`)
  }

  const [codeRaw, targetRaw] = args.join(' ').split('|')
  const code = codeRaw?.trim().toUpperCase()
  const target = targetRaw?.trim()
  if (!code || !target) return m.reply('Format salah! Contoh: .order FF100 | 123456789')

  const cleanTarget = target.replace(/\D/g, '') + (target.includes('(') ? target.match(/\((.*?)\)/)?.[0] || '' : '')
  if (cleanTarget.length < 8) return m.reply('Nomor/ID tidak valid!')

  const proses = await m.reply('Membuat pesanan & QRIS...')

  try {
    // 1. Buat order dulu
    const orderRes = await fetch(`${global.khafaBaseUrl}/h2h/order/create?code=${code}&tujuan=${cleanTarget}`, {
      headers: { 'X-APIKEY': global.khafaApiKey }
    })
    const orderJson = await orderRes.json()
    if (!orderJson.success) return conn.sendMessage(m.chat, { text: `Gagal buat order: ${orderJson.message}`, edit: proses.key })

    const order = orderJson.data
    const harga = parseInt(order.price)
    const adminFee = Math.floor(Math.random() * 151) + 100 // 100-250 random
    const total = harga + adminFee

    // 2. Buat QRIS deposit
    const depositRes = await fetch(`${global.khafaBaseUrl}/h2h/deposit/create?${qs.stringify({ nominal: total })}`, {
      headers: { 'X-APIKEY': global.khafaApiKey }
    })
    const depositJson = await depositRes.json()
    if (!depositJson.success || !depositJson.data?.qr_string) {
      return conn.sendMessage(m.chat, { text: 'Gagal buat QRIS!', edit: proses.key })
    }

    const deposit = depositJson.data
    const qrBuffer = await generateCustomQR(deposit.qr_string)

    // Simpan ke pending
    pendingData[deposit.id] = {
      deposit_id: deposit.id,
      order_reff: order.reff_id,
      layanan: order.layanan,
      target: cleanTarget,
      harga,
      total,
      user: m.sender,
      waktu: Date.now()
    }
    savePending()

    const caption = `
*INVOICE PEMBAYARAN QRIS*

Layanan   : ${order.layanan}
Nomor/ID  : ${cleanTarget}
Harga     : Rp ${harga.toLocaleString()}
Admin     : Rp ${adminFee.toLocaleString()}
*Total*   : Rp ${total.toLocaleString()}

Reff ID   : ${order.reff_id}
Expired   : ${moment(deposit.expired_at).tz('Asia/Jakarta').format('DD/MM HH:mm')}

Scan QRIS di atas untuk bayar
*Pesanan akan otomatis diproses & kamu dapat notif "PESANAN BERHASIL" dalam 10-30 detik setelah bayar*
    `.trim()

    await conn.sendMessage(m.chat, { image: qrBuffer, caption }, { quoted: m })
    conn.sendMessage(m.chat, { delete: proses.key })

  } catch (e) {
    console.error(e)
    m.reply('Error sistem, coba lagi 1 menit')
  }
}

handler.help = ['order <kode|nomor>']
handler.tags = ['khafa']
handler.command = /^order$/i
export default handler

// === AUTO DETEKSI BAYAR → LANGSUNG KIRIM "PESANAN BERHASIL" + SN (KALAU ADA) ===
setInterval(async () => {
  if (Object.keys(pendingData).length === 0) return

  fetch(`${global.khafaBaseUrl}/h2h/mutasi`, {
    headers: { 'X-APIKEY': global.khafaApiKey }
  })
  .then(res => res.json())
  .then(json => {
    if (!json.success) return

    // Cek deposit masuk
    json.mutasiDeposit?.forEach(dep => {
      if (pendingData[dep.id] && dep.status === "success") {
        pendingData[dep.id].paid = true
        savePending()
      }
    })

    // Cek order sukses → kirim notif
    json.mutasiOrder?.forEach(async (ord) => {
      const found = Object.values(pendingData).find(p => p.order_reff === ord.reff_id)
      if (found && ord.status === "success" && found.paid) {
        const teks = `
*PESANAN BERHASIL!*

Layanan   : ${ord.layanan}
Nomor/ID  : ${found.target}
Total     : Rp ${found.total.toLocaleString()}

${ord.sn ? `*SN/Kode:*\n\`${ord.sn}\`` : 'Diamond/Pulsa/Token sudah masuk langsung!'}

Terima kasih sudah order
Waktu: ${moment().tz('Asia/Jakarta').format('DD MMMM YYYY - HH:mm:ss')}
        `.trim()

        await global.conn.sendMessage(found.user, { text: teks })
        delete pendingData[Object.keys(pendingData).find(k => pendingData[k].order_reff === ord.reff_id)]
        savePending()
      }
    })
  })
  .catch(() => {})
}, 5000) // cek tiap 5 detik