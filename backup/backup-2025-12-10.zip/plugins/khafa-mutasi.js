import fetch from 'node-fetch'
import fs from 'fs'

async function checkMutasi(conn) {

  if (!global.pendingPanel || global.pendingPanel.length === 0) return

  try {
    const res = await fetch(`${global.khafaBaseUrl}/h2h/mutasi`, {
      method: 'GET',
      headers: {
        'X-APIKEY': global.khafaApiKey,
        'Content-Type': 'application/json'
      }
    })

    const json = await res.json()
    if (!json.success) return

    const mutasi = json.mutasiDeposit
    if (!mutasi || mutasi.length === 0) return

    for (let trx of global.pendingPanel) {

      const find = mutasi.find(m => 
        Number(m.get_balance) === Number(trx.harga) &&
        m.status.toLowerCase() === 'success'
      )

      if (!find) continue

      const params = new URLSearchParams({
        username: trx.username,
        paket: trx.paket
      })

      const resOrder = await fetch(`${global.khafaBaseUrl}/h2h/order-panel?${params}`, {
        method: 'GET',
        headers: {
          'X-APIKEY': global.khafaApiKey,
          'Content-Type': 'application/json'
        }
      })

      const jsonOrder = await resOrder.json()

      if (!jsonOrder.success) {
        await conn.sendMessage(trx.user, { text: `Gagal memproses order panel.\n\nResponse:\n${JSON.stringify(jsonOrder, null, 2)}` })
        continue
      }

      const d = jsonOrder.data

      const caption = `
Order Panel Berhasil

ID Transaksi: ${d.id}
Referensi: ${d.reff_id}
Layanan: ${d.layanan}
Username: ${d.target}
Paket: ${d.code}
Harga: ${trx.harga}
Status: ${d.status}

Akun Panel:
Username: ${d.user.username}
Email: ${d.user.email}
Password: ${d.user.password}

Detail Server:
ID: ${d.server.id}
Memory: ${d.server.memory} MB
Disk: ${d.server.disk} MB
CPU: ${d.server.cpu}%
`.trim()

      await conn.sendMessage(trx.user, { text: caption })

      global.pendingPanel = global.pendingPanel.filter(v => v.reff !== trx.reff)
    }

  } catch (e) {
    console.log('Error Mutasi:', e)
  }
}

/* === JALANKAN TIAP 15 DETIK === */
setInterval(async () => {
  if (global.conn) {
    await checkMutasi(global.conn)
  }
}, 15000)

let handler = async () => {}

export default handler