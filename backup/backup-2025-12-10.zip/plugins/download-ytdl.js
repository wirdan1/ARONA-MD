import axios from "axios";

class YouTubeDownloader {
  static API_URL = "https://host.optikl.ink/download/youtube";

  static FORMATS = {
    mp3: "MP3 (Audio Only)",
    144: "144p",
    240: "240p",
    360: "360p",
    480: "480p",
    720: "720p (HD)",
    1080: "1080p (Full HD)"
  };

  static async fetchVideoInfo(url, format = "720") {
    if (!url.includes("youtube.com") && !url.includes("youtu.be")) {
      throw new Error("URL harus dari YouTube!");
    }

    const fmt = format.toLowerCase();
    if (!this.FORMATS[fmt]) {
      throw new Error(`Format tidak didukung!\nTersedia: ${Object.keys(this.FORMATS).join(", ")}`);
    }

    const { data } = await axios.get(this.API_URL, {
      params: { url, format: fmt },
      timeout: 60000,
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    if (!data.status || data.code !== 200) {
      throw new Error(data.message || "Gagal mengambil info video");
    }

    const r = data.result;
    return {
      title: r.title || "Tanpa Judul",
      duration: this.formatDuration(r.duration),
      thumbnail: r.thumbnail,
      quality: r.quality || fmt.toUpperCase(),
      downloadUrl: r.download,
      type: fmt === "mp3" ? "audio" : "video",
      ext: fmt === "mp3" ? "mp3" : "mp4"
    };
  }

  static formatDuration(seconds) {
    if (!seconds) return "00:00";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return h > 0 ? `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}` : `${m}:${s.toString().padStart(2, "0")}`;
  }
}

let handler = async (m, { conn, text, usedPrefix }) => {
  if (!text) return m.reply(`Penggunaan:\n${usedPrefix}ytdl <link youtube> [format]\n\nContoh:\n${usedPrefix}ytdl https://youtu.be/dQw4w9WgXcQ\n${usedPrefix}ytdl https://youtu.be/dQw4w9WgXcQ mp3\n${usedPrefix}ytdl https://youtu.be/dQw4w9WgXcQ 1080`);

  let [url, format = "720"] = text.trim().split(" ");
  format = format.toLowerCase();

  if (!/^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//.test(url)) {
    return m.reply("Link YouTube tidak valid!");
  }

  m.reply("Sedang diproses, sabar ya...");

  try {
    const info = await YouTubeDownloader.fetchVideoInfo(url, format);

    const caption = `*YOUTUBE DOWNLOADER*

Judul: ${info.title}
Durasi: ${info.duration}
Kualitas: ${info.quality}

Sedang dikirim...`.trim();

    let thumbnailBuffer = null;
    if (info.thumbnail) {
      try {
        const res = await axios.get(info.thumbnail, { responseType: "arraybuffer", timeout: 10000 });
        thumbnailBuffer = Buffer.from(res.data);
      } catch {}
    }

    if (info.type === "audio") {
      await conn.sendMessage(m.chat, {
        audio: { url: info.downloadUrl },
        mimetype: "audio/mpeg",
        fileName: `${info.title}.mp3`,
        caption
      }, { quoted: m });
    } else {
      await conn.sendMessage(m.chat, {
        video: { url: info.downloadUrl },
        mimetype: "video/mp4",
        caption,
        jpegThumbnail: thumbnailBuffer
      }, { quoted: m });
    }

    conn.sendMessage(m.chat, { react: { text: "success", key: m.key } });

  } catch (e) {
    console.log(e);
    conn.sendMessage(m.chat, { react: { text: "error", key: m.key } });
    m.reply(`Gagal download!\n${e.message}`);
  }
};

handler.help = ["ytdl <link> [format]"];
handler.tags = ["download"];
handler.command = /^ytdl$/i;
handler.limit = true;

export default handler;