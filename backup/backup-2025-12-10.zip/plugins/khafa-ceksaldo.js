/*
   Plugin KhafaTopUp - Profile & Cek Saldo
   API: https://khafatopup.my.id/h2h/profile
   Dibuat khusus buat kamu yang ganteng
*/

import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command }) => {
    let apikey = global.khafaApiKey
    if (!apikey || apikey.includes("your_api_key_here")) {
        return m.reply(`Warning API Key KhafaTopUp belum diatur!\n\nSilahkan isi di *settings.js*:\n\nglobal.khafaApiKey = "apikey_lo_disini"`)
    }

    m.reply("Sedang mengambil data profil...")

    try {
        let res = await fetch("https://khafatopup.my.id/h2h/profile", {
            method: "GET",
            headers: {
                "X-APIKEY": apikey,
                "Content-Type": "application/json"
            }
        })

        if (!res.ok) {
            let errorText = await res.text()
            throw `HTTP ${res.status}: ${errorText || "Gagal terhubung ke server"}`
        }

        let json = await res.json()

        if (!json.success) {
            throw json.message || "Gagal mengambil data profil"
        }

        let user = json.user

        let teks = `
*「 KHAFA TOPUP PROFILE 」*

Nama Lengkap: ${user.fullname}
Username: ${user.username}
Nomor HP: ${user.nomor}
Email: ${user.email}
Role: ${user.role.toUpperCase()}
Status: ${user.isVerified ? "Terverifikasi" : "Belum Verifikasi"}
Saldo: Rp ${Number(user.saldo).toLocaleString('id-ID')}
Coin: ${user.coin.toLocaleString('id-ID')}
Referral Code: ${user.referralCode || "-"}

Terdaftar Sejak: ${formatDate(user.tanggalDaftar)}
Login Terakhir: ${formatDate(user.lastLogin)}

Profile Picture:
${user.profileUrl || "Tidak tersedia"}
`.trim()

        // Kirim dengan thumbnail kalau ada foto profil
        if (user.profileUrl && user.profileUrl.includes('http')) {
            await conn.sendMessage(m.chat, {
                image: { url: user.profileUrl },
                caption: teks
            }, { quoted: m })
        } else {
            await conn.reply(m.chat, teks, m)
        }

    } catch (e) {
        console.log(e)
        m.reply(`Failed Gagal mengambil data profil!\n\n${e}\n\nCek apikey kamu di settings.js sudah benar atau belum.`)
    }
}

handler.help = ['profile', 'ceksaldo', 'khafa']
handler.tags = ['khafa']
handler.command = /^(profile|ceksaldo|khafa(profil|topup)?)$/i
handler.limit = false
handler.owner = true

export default handler

// Format tanggal biar cakep
function formatDate(iso) {
    if (!iso) return "-"
    let date = new Date(iso)
    let options = { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' }
    return date.toLocaleDateString('id-ID', options) + " WIB"
}