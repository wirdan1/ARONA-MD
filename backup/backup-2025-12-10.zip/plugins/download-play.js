import axios from 'axios'
import yts from 'yt-search'
import { toPTT } from '../function/converter.js'

let handler = async (m, { conn, args, command, usedPrefix }) => {
    if (!args[0]) return m.reply(
`ᴋᴇᴛɪᴋ ᴊᴜᴅᴜʟ ʟᴀɢᴜɴʏᴀ♡

ᴄᴏɴᴛᴏʜ:
${usedPrefix + command} dj aku bukan boneka`
    )

    let status = await conn.reply(m.chat, `sᴇᴅᴀɴɢ ᴍᴇɴᴄᴀʀɪ ʟᴀɢᴜ...`, m)

    try {
        let query = args.join(' ')
        let search = await yts(query)

        if (!search.videos.length) {
            await conn.sendMessage(m.chat, { text: `ʟᴀɢᴜ ɢᴀᴋ ᴋᴇᴛᴇᴍᴜ :(` }, { quoted: m })
            return
        }

        let vid = search.videos[0]
        const apiUrl = `https://api.yupra.my.id/api/downloader/ytmp3?url=${encodeURIComponent(vid.url)}`
        const { data } = await axios.get(apiUrl)

        if (!data.success || !data.data?.download_url) throw 'Audio tidak ditemukan'

        let res = data.data
        let audioBuffer = (await axios.get(res.download_url, { responseType: 'arraybuffer' })).data
        let { data: opusData } = await toPTT(audioBuffer, 'mp3')

        await conn.sendMessage(m.chat, {
            audio: opusData,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: res.title.slice(0, 30),
                    body: `${res.duration}s`,
                    thumbnailUrl: res.thumbnail,
                    sourceUrl: vid.url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

        await conn.sendMessage(m.chat, { text: `sᴇʟᴇsᴀɪ♡`, edit: status.key })

    } catch (e) {
        console.log(e)
        await conn.sendMessage(m.chat, { text: `ɢᴀɢᴀʟ ᴘʀᴏsᴇs :(`, edit: status.key })
    }
}

handler.help = ['play']
handler.tags = ['download']
handler.command = /^play$/i
handler.limit = true

export default handler