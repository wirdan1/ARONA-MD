import fs from "fs";
import path from "path";
import axios from "axios";
import archiver from "archiver";
import { tmpdir } from "os";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const GITHUB = {
    username: "teamhookrest-prog",
    token: "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"
};

const github = axios.create({
    baseURL: "https://api.github.com",
    headers: {
        Authorization: `Bearer ${GITHUB.token}`,
        Accept: "application/vnd.github+json",
        "User-Agent": "BackupBot"
    }
});

async function repoExists(repoName) {
    try {
        await github.get(`/repos/${GITHUB.username}/${repoName}`);
        return true;
    } catch {
        return false;
    }
}

async function createRepo(repoName) {
    return github.post(`/user/repos`, {
        name: repoName,
        auto_init: true,
        private: true
    });
}

async function getFileSha(repoName, remotePath) {
    try {
        const { data } = await github.get(`/repos/${GITHUB.username}/${repoName}/contents/${remotePath}`);
        return data.sha;
    } catch {
        return null;
    }
}

async function uploadToGithub(repoName, filePath, remotePath) {
    const content = fs.readFileSync(filePath).toString("base64");
    const sha = await getFileSha(repoName, remotePath);

    await github.put(`/repos/${GITHUB.username}/${repoName}/contents/${remotePath}`, {
        message: `Backup update: ${remotePath}`,
        content,
        sha: sha || undefined
    });
}

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply(`Format salah.\nGunakan: .backup <nama_repository>`);

    const repoName = text.trim();
    const tempPath = path.join(tmpdir(), `backup-${Date.now()}.zip`);

    await m.reply(`Membuat backup bot...`);

    try {
        const output = fs.createWriteStream(tempPath);
        const archive = archiver("zip", { zlib: { level: 9 } });

        archive.pipe(output);

        archive.glob("**/*", {
            cwd: path.join(__dirname, ".."),
            ignore: [
                "*.zip",
                "node_modules/**",
                ".git/**",
                "tmp/**",
                "session*/**",
                "auth*/**",
                "store*/**",
                "creds.json",
                "database.json",
                ".env",
                "baileys_store*/**",
                "package-lock.json",
                "yarn.lock"
            ]
        });

        await archive.finalize();
        await new Promise(resolve => output.on("close", resolve));

        const fileSize = fs.statSync(tempPath).size / (1024 * 1024);
        if (fileSize > 100) {
            fs.unlinkSync(tempPath);
            return m.reply(`Backup gagal. File melebihi batas maksimum 100MB.\nUkuran: ${fileSize.toFixed(2)}MB`);
        }

        const fileName = `backup-${new Date().toISOString().slice(0, 10)}.zip`;

        const exists = await repoExists(repoName);
        if (!exists) {
            await m.reply(`Repository tidak ditemukan. Membuat repository baru...`);
            await createRepo(repoName);
        }

        await m.reply(`Mengupload backup ke GitHub...`);
        await uploadToGithub(repoName, tempPath, `backup/${fileName}`);

        fs.unlinkSync(tempPath);

        const repoURL = `https://github.com/${GITHUB.username}/${repoName}`;

        return m.reply(
`Backup selesai.

Repository:
${repoURL}

Lokasi file:
backup/${fileName}

Waktu:
${new Date().toLocaleString("id-ID")}`
        );

    } catch (err) {
        console.error(err);
        return m.reply("Backup gagal: " + err.message);
    }
};

handler.help = ["backup <repo>"];
handler.tags = ["owner"];
handler.command = /^backup|bkp$/i;
handler.owner = true;

export default handler;