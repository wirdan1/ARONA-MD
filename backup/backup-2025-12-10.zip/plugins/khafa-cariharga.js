/*
   .harga <nama produk / provider / kode>
   Contoh: .harga telkomsel
           .harga xl 10k
           .harga TSEL5GB
           .harga dana
   Langsung tampil harga + status + note!
*/

import fetch from 'node-fetch'

let cachedData = null
let lastUpdate = 0

let handler = async (m, { conn, text }) => {
    let apikey = global.khafaApiKey
    if (!apikey || apikey.includes("your_api_key_here")) {
        return m.reply(`Warning API Key KhafaTopUp belum diatur!\n\nIsi di settings.js:\n\nglobal.khafaApiKey = "apikey_lo"`)
    }

    // Kalau gak ada query → tampilkan pricelist lengkap
    if (!text) {
        return m.reply("Ketik nama produk / provider / kode yang mau dicari!\n\nContoh:\n.harga telkomsel\n.harga dana\n.harga TSEL5GB\n.harga ml 100")
    }

    m.reply("Mencari produk...")

    try {
        // Cache 5 menit biar cepet
        if (!cachedData || Date.now() - lastUpdate > 5 * 60 * 1000) {
            const res = await fetch('https://khafatopup.my.id/h2h/layanan/price-list', {
                headers: { 'X-APIKEY': apikey }
            })
            if (!res.ok) throw "Gagal ambil data"
            const json = await res.json()
            if (!json.success) throw "API error"
            cachedData = json.data
            lastUpdate = Date.now()
        }

        const query = text.toLowerCase().trim()
        const results = cachedData.filter(item => 
            item.name.toLowerCase().includes(query) ||
            item.provider.toLowerCase().includes(query) ||
            item.code.toLowerCase().includes(query) ||
            item.category.toLowerCase().includes(query)
        )

        if (results.length === 0) {
            return m.reply(`Produk "${text}" tidak ditemukan!\n\nCoba ketik keyword lain atau gunakan .pricelist untuk lihat semua.`)
        }

        let teks = `*HASIL PENCARIAN: "${text.toUpperCase()}"*\n\n`
        teks += `_Ditemukan ${results.length} produk_\n\n`

        results.slice(0, 20).forEach((p, i) => { // Max 20 hasil biar gak spam
            const status = p.status === "available" ? "Aktif" : "Tidak Aktif"
            const harga = Number(p.price).toLocaleString('id-ID')
            teks += `${i + 1}. *${p.provider}* - ${p.name}\n`
            teks += `   ├ Status: ${status}\n`
            teks += `   ├ Harga: *Rp ${harga}*\n`
            teks += `   ├ Kode: \`${p.code}\`\n`
            if (p.note) teks += `   └ Catatan: ${p.note}\n`
            teks += `\n`
        })

        if (results.length > 20) teks += `_Dan ${results.length - 20} produk lainnya..._\n`

        teks += `_Update: ${new Date(lastUpdate).toLocaleString('id-ID')}_`

        await conn.sendMessage(m.chat, {
            text: teks.trim(),
            contextInfo: {
                externalAdReply: {
                    title: "KHAFA TOPUP - CARI HARGA CEPAT",
                    body: "Tanya harga? Langsung ketik .harga [produk]",
                    thumbnailUrl: "https://qu.ax/bJwgg.jpg",
                    sourceUrl: "https://khafatopup.my.id",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.log(e)
        m.reply(`Gagal cari produk!\n\n${e}\n\nCoba lagi nanti ya bro.`)
    }
}

handler.help = ['harga']
handler.tags = ['khafa']
handler.command = /^(harga)$/i

export default handler