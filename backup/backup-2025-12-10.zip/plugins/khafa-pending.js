import fetch from 'node-fetch'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) {
        return m.reply(
`Masukkan ID order yang ingin dicek.

Contoh:
${usedPrefix + command} ORDER123ABC456`
        )
    }

    const orderId = args[0].trim()

    await m.reply(`Mengecek order *${orderId}* ...`)

    try {

        const params = new URLSearchParams({ id: orderId })

        const res = await fetch(`https://khafatopup.my.id/h2h/order/check?${params}`, {
            method: 'GET',
            headers: {
                'X-APIKEY': global.khafaApiKey,
                'Content-Type': 'application/json'
            }
        })

        const json = await res.json()

        if (!json.status) {
            return m.reply(
`*CEK ORDER*

Status  : Tidak ditemukan
ID      : ${orderId}

Silakan pastikan ID order sudah benar.`
            )
        }

        const d = json.data

        let caption = `
*CEK ORDER*

ID           : ${d.id}
Reff         : ${d.reff_id}
Layanan      : ${d.layanan}
Code         : ${d.code}
Target       : ${d.target}
Harga        : Rp ${Number(d.price).toLocaleString('id-ID')}
Status       : ${d.status}
Tanggal      : ${d.created_at}
SN           : ${d.sn ? d.sn : '-'}
`.trim()

        await m.reply(caption)

    } catch (e) {
        console.log(e)
        m.reply('Gagal mengecek order!')
    }
}

handler.help = ['pending <id>']
handler.tags = ['khafa']
handler.command = /^pending$/i

export default handler