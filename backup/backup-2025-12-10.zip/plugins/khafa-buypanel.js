import fetch from 'node-fetch'
import qs from 'qs'
import QRCode from 'qrcode'
import { createCanvas, loadImage } from 'canvas'
import moment from 'moment-timezone'

/* --- FUNCTION GENERATE QR CUSTOM --- */

async function generateCustomQRFromString(qrText) {
  const canvas = createCanvas(720, 1080)
  const ctx = canvas.getContext('2d')

  const bg = await loadImage('./media/qrisscustom.jpg')
  ctx.drawImage(bg, 0, 0, canvas.width, canvas.height)

  const qrBaseWidth = 265
  const qrBaseHeight = 260

  const expandKiri = 5
  const shrinkKiri = 2

  const expandKanan = 3
  const shrinkKanan = 0

  const expandAtas = 0
  const shrinkAtas = 35

  const expandBawah = 3
  const shrinkBawah = 0

  const qrWidth = qrBaseWidth + expandKiri + expandKanan - shrinkKiri - shrinkKanan
  const qrHeight = qrBaseHeight + expandAtas + expandBawah - shrinkAtas - shrinkBawah

  const offsetGlobalX = 2
  const offsetGlobalY = 7

  const qrCanvas = createCanvas(qrWidth, qrHeight)
  await QRCode.toCanvas(qrCanvas, qrText, {
    errorCorrectionLevel: 'H',
    margin: 1,
    width: qrWidth
  })

  const baseX = (canvas.width - qrBaseWidth) / 2
  const baseY = 610

  const qrX = baseX - expandKiri + shrinkKiri + offsetGlobalX
  const qrY = baseY - expandAtas + shrinkAtas + offsetGlobalY

  ctx.shadowColor = 'rgba(0,0,0,0.3)'
  ctx.shadowBlur = 10
  ctx.drawImage(qrCanvas, qrX, qrY, qrWidth, qrHeight)
  ctx.shadowBlur = 0

  return canvas.toBuffer()
}

/* --- MAIN HANDLER --- */

let handler = async (m, { conn, usedPrefix, command, args }) => {
  if (!args[0]) {
    return m.reply(
`Masukkan format pembelian panel.

Format:
${usedPrefix + command} username | paket

Contoh:
${usedPrefix + command} khafa | 2gb`
    )
  }

  const input = args.join(' ').split('|')
  const username = input[0]?.trim()
  const paket = input[1]?.trim()?.toLowerCase()

  if (!username || !paket) {
    return m.reply(
`Format salah.

Contoh:
${usedPrefix + command} khafa | 2gb`
    )
  }

  // === Harga Panel + Fee Admin ===
  const pricePanel = {
    '1gb': 1700,
    '2gb': 2200,
    '3gb': 3500,
    '4gb': 4500,
    '5gb': 5700,
    'unli': 16500
  }

  if (!pricePanel[paket]) {
    return m.reply(
`Paket panel tidak ditemukan.

Daftar Paket:
${Object.keys(pricePanel).map(v => '- ' + v).join('\n')}`
    )
  }

  const basePrice = pricePanel[paket]
  const feeAdmin = Math.floor(Math.random() * (200 - 50 + 1)) + 50
  const totalHarga = basePrice + feeAdmin

  await m.reply(`Membuat QRIS untuk pembayaran sebesar Rp${totalHarga}...`)

  try {
    // === CREATE DEPOSIT VIA QR ===
    const q = qs.stringify({ nominal: totalHarga })
    const urlDeposit = `${global.khafaBaseUrl}/h2h/deposit/create?${q}`

    const resDep = await fetch(urlDeposit, {
      method: 'GET',
      headers: {
        'X-APIKEY': global.khafaApiKey,
        'Content-Type': 'application/json'
      }
    })

    const jsonDep = await resDep.json()
    if (!jsonDep.success) {
      return m.reply(
`Gagal membuat QR Deposit.

Response:
${JSON.stringify(jsonDep, null, 2)}`
      )
    }

    const d = jsonDep.data
    if (!d.qr_string) return m.reply('QR string tidak diterima dari API.')

    // === GENERATE QR CUSTOM ===
    let qrImageBuffer = await generateCustomQRFromString(d.qr_string)

    // === KIRIM QR DAN INSTRUKSI ===
    const caption = `
*Pembelian Panel ${paket.toUpperCase()}*

Total: Rp${totalHarga}
Harga Asli: Rp${basePrice}
Fee Admin: Rp${feeAdmin}

Silahkan scan QR di bawah ini untuk membayar deposit otomatis.

Setelah pembayaran berhasil (mutasi terdeteksi), panel akan otomatis dibuat dengan username: ${username}.
`.trim()

    await conn.sendMessage(m.chat, { image: qrImageBuffer, caption }, { quoted: m })

    // === SIMPAN DATA ORDER UNTUK NANTI AUTO PROSES ===
    global.pendingPanel = global.pendingPanel || []
    global.pendingPanel.push({
      user: m.sender,
      username,
      paket,
      harga: totalHarga,
      nominal: d.nominal,
      reff: d.reff_id,
      time: Date.now()
    })

  } catch (e) {
    console.log(e)
    m.reply('Gagal membuat QRIS deposit.')
  }
}

handler.help = ['buypanel']
handler.tags = ['khafa']
handler.command = /^(buypanel|panel)$/i

export default handler