// === ORDER V2: LANGSUNG PAKAI SALDO KHAFA (TANPA QRIS) ===
// KODE UTAMA TETAP SAMA PERSIS SEPERTI YANG SUDAH WORK DI KAMU
import fetch from 'node-fetch'
import moment from 'moment-timezone'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    return m.reply(`*Format Order Langsung (Pakai Saldo)*

Contoh:
${usedPrefix + command} TSEL10GB | 085156789012
${usedPrefix + command} ML500 | 12345678(4321)
${usedPrefix + command} PLN50 | 531234567890`)
  }

  const input = args.join(' ').split('|')
  const code = input[0]?.trim().toUpperCase()
  const target = input[1]?.trim()

  if (!code || !target) {
    return m.reply(`Format salah!\nContoh: ${usedPrefix + command} AXIS5GB | 083812345678`)
  }

  const cleanTarget = target.replace(/\D/g, '') + (target.includes('(') ? target.match(/\((.*?)\)/)?.[0] || '' : '')
  if (cleanTarget.length < 8) {
    return m.reply('Nomor/ID terlalu pendek atau tidak valid!')
  }

  const wait = await m.reply('Memproses order langsung menggunakan saldo...\nMohon tunggu 5–15 detik')

  try {
    const params = new URLSearchParams({ code, tujuan: cleanTarget })
    const response = await fetch(`${global.khafaBaseUrl}/h2h/order/create?${params}`, {
      method: 'GET',
      headers: {
        'X-APIKEY': global.khafaApiKey,
        'Content-Type': 'application/json'
      }
    })

    const json = await response.json()

    if (json.message && json.message.toLowerCase().includes('saldo tidak mencukupi')) {
      return conn.sendMessage(m.chat, {
        text: `SALDO KHAFA KOSONG / TIDAK CUKUP!\n\nOrder tidak bisa diproses sampai admin isi ulang saldo.\n\nCoba lagi nanti ya kak`,
        edit: wait.key
      })
    }

    if (!json.success) {
      return conn.sendMessage(m.chat, {
        text: `Gagal order:\n${json.message || JSON.stringify(json)}`,
        edit: wait.key
      })
    }

    const order = json.data
    const reff = order.reff_id

    await conn.sendMessage(m.chat, {
      text: `
ORDER DITERIMA & SEDANG DIPROSES

Layanan: ${order.layanan}
Nomor/ID: ${cleanTarget}
Harga: Rp ${parseInt(order.price).toLocaleString()}
Reff ID: ${reff}

Tunggu 5–20 detik, akan otomatis terkirim bukti berhasil!
      `.trim(),
      edit: wait.key
    })

    // Simpan pending
    global.pendingDirect = global.pendingDirect || {}
    global.pendingDirect[reff] = {
      user: m.sender,
      chat: m.chat,
      layanan: order.layanan,
      target: cleanTarget,
      price: order.price,
      waktu: moment().tz('Asia/Jakarta').format('DD/MM HH:mm')
    }

  } catch (err) {
    console.error(err)
    m.reply('Terjadi error sistem. Coba lagi dalam 1 menit.')
  }
}

handler.help = ['buy <kode|nomor/id>']
handler.tags = ['khafa']
handler.command = /^buy$/i
export default handler

// === AUTO KIRIM "PEMBAYARAN BERHASIL" LANGSUNG (TANPA NUNGGU SN) ===
setInterval(async () => {
  try {
    if (!global.pendingDirect || Object.keys(global.pendingDirect).length === 0) return

    const res = await fetch(`${global.khafaBaseUrl}/h2h/mutasi`, {
      headers: { 'X-APIKEY': global.khafaApiKey }
    })

    if (!res.ok) return
    const json = await res.json()
    if (!json.success || !json.mutasiOrder) return

    for (const order of json.mutasiOrder) {
      const data = global.pendingDirect[order.reff_id]
      if (!data) continue

      // KALAU STATUS SUCCESS → LANGSUNG KIRIM BUKTI BERHASIL (ada SN atau enggak tetap kirim)
      if (order.status === "success") {
        const pesanSukses = `
*PEMBAYARAN BERHASIL!*

Layanan   : ${order.layanan}
Nomor/ID  : ${data.target}
Harga     : Rp ${parseInt(data.price).toLocaleString()}

${order.sn ? `*SN/Kode Voucher:*\n\`${order.sn}\`` : 'Produk sudah langsung masuk ke tujuan (Diamond/Pulsa/Token)'}

Terima kasih telah order  
Waktu: ${moment().tz('Asia/Jakarta').format('DD MMMM YYYY - HH:mm:ss')}
        `.trim()

        await global.conn.sendMessage(data.user, { text: pesanSukses })
        delete global.pendingDirect[order.reff_id]
      }
    }
  } catch (err) {
    console.error('Error cek mutasi:', err.message)
  }
}, 5000) // cek tiap 5 detik → cepet banget nangkep!